package publish;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TimePicker;

import com.android.volley.AuthFailureError;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.myapp.R;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import login.MainActivity;

public class publishByTime extends AppCompatActivity implements View.OnClickListener {
    private StringBuffer time=new StringBuffer();
    private StringBuffer time2=new StringBuffer();
    String MyUrl = "http://iotc.okay3r.top";
    private String startTime;
    private String endTime;
    private static final String TAG = "publishByTime";
    private Button start_btn;
    private Button end_btn;
    private Button time_btn;
    private String aa;
    private String bb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_publish_by_time);
        start_btn = findViewById(R.id.start_publish_btn);
        end_btn = findViewById(R.id.end_publish_btn);
        time_btn = findViewById(R.id.time_publish_search);
        start_btn.setOnClickListener(this);
        end_btn.setOnClickListener(this);
        time_btn.setOnClickListener(this);
    }
    //选择开始时间
    public void showTime(){
        Calendar cal=Calendar.getInstance();
        int year=cal.get(Calendar.YEAR);
        final int month=cal.get(Calendar.MONTH);
        final int day=cal.get(Calendar.DAY_OF_MONTH);
        new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int selectYear, int selectMonth, int selectDay) {
                time.append(selectYear).append("/").append(selectMonth+1).append("/").append(selectDay).append(" ");
            }
        },year,month,day).show();
    }
    //选择结束时间
    public void showDate(){
        Calendar cal2=Calendar.getInstance();
        int hour=cal2.get(Calendar.HOUR);
        int min=cal2.get(Calendar.MINUTE);
        final int sec=cal2.get(Calendar.SECOND);
        new TimePickerDialog(this,new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                time.append(hourOfDay).append(":").append(minute).append(":").append(sec);
                startTime = time.toString();
                Log.e(TAG, startTime+" " );
            }
        },hour,min,true).show();
    }
    //选择结束时间
    public void showEndTime(){
        Calendar cal=Calendar.getInstance();
        int year=cal.get(Calendar.YEAR);
        final int month=cal.get(Calendar.MONTH);
        final int day=cal.get(Calendar.DAY_OF_MONTH);
        new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int selectYear, int selectMonth, int selectDay) {
                time2.append(selectYear).append("/").append(selectMonth+1).append("/").append(selectDay).append(" ");
            }
        },year,month,day).show();
    }
    //选择结束时间
    public void showEndDate(){
        Calendar cal2=Calendar.getInstance();
        int hour=cal2.get(Calendar.HOUR);
        int min=cal2.get(Calendar.MINUTE);
        final int sec=cal2.get(Calendar.SECOND);
        new TimePickerDialog(this,new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                time2.append(hourOfDay).append(":").append(minute).append(":").append(sec);
                endTime = time2.toString();
                Log.e(TAG, endTime+" " );
            }
        },hour,min,true).show();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.start_publish_btn:
                showDate();
                showTime();
                break;
            case R.id.end_publish_btn:
                showEndDate();
                showEndTime();
                break;
            case R.id.time_publish_search:
                //使用Volley框架请求数据
                RequestQueue requestQueue= Volley.newRequestQueue(this);
                try {
                    aa = URLEncoder.encode(startTime,"utf-8");
                    bb = URLEncoder.encode(endTime,"utf-8");
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }

                StringRequest stringRequest=new StringRequest(MyUrl+"/pub/queryByTime?start="+aa+"&end="+bb, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.e(TAG, "onResponse: "+response);
                        Intent intent3=new Intent(publishByTime.this, show_publish_by_time.class);
                        intent3.putExtra("publishTimeData",response);
                        startActivity(intent3);
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e(TAG, "onErrorResponse: "+"请求失败" );
                    }
                }){
                    //设置请求头
                    @Override
                    public Map<String, String> getHeaders() throws AuthFailureError {
                        HashMap<String ,String> map=new HashMap<>();
                        map.put("username", MainActivity.username);
                        map.put("secretKey", MainActivity.key);
                        return map;
                    }

                 /*   @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        HashMap<String,String> map=new HashMap<>();
                        map.put("start",startTime);
                        map.put("end",endTime);
                        return map;
                    }*/
                };
                requestQueue.add(stringRequest);
                break;
        }
    }
}
