package publish;

import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.myapp.R;
import com.example.myapp.showDataActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import login.MainActivity;
import login.registerActivity;
import model.UserBo;
import model.publishBo;

public class send_publish extends AppCompatActivity {

    private EditText payload;
    private EditText qos;
    private EditText topic;
    private Button btn;
    private String payLoadData;
    private int qosData;
    private String topicData;
    private model.publishBo publishBo;
    private static final String TAG = "send_publish";
    private String MyURL="http://iotc.okay3r.top//pub/doSend";
    //跳转回主页面
    private Handler handler=new Handler(){
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what){
                case 1:
                    //跳转到登录界面
                    Intent intent=new Intent(send_publish.this, showDataActivity.class);
                    startActivity(intent);
                    Toast.makeText(send_publish.this,"发送消息成功",Toast.LENGTH_SHORT).show();
                    break;
            }

        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_publish);
        payload = findViewById(R.id.send_publish_payload);
        qos = findViewById(R.id.send_publish_qos);
        topic = findViewById(R.id.send_publish_topic);
        btn = findViewById(R.id.send_publish_btn);
        btn.setOnClickListener(new MyLintener());
    }
    private void sendHttpPostRequest(final publishBo publishBo){
        //开启一个线程进行网络请求
        new Thread(new Runnable() {
            HttpURLConnection connection;
            @Override
            public void run() {
                try {
                    StringBuilder sb=new StringBuilder();
                    //向json对象中添加数据
                    JSONObject jb=new JSONObject();
                    jb.put("qos",publishBo.getQos());
                    jb.put("topic",publishBo.getTopic());
                    jb.put("payload",publishBo.getPayload());
                    //发送post请求
                    URL url=new URL(MyURL);
                    connection= (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("POST");
                    connection.setConnectTimeout(100000);
                    //请求添加密钥和用户名
                    connection.setRequestProperty("username", MainActivity.username);
                    connection.setRequestProperty("secretKey", MainActivity.key);
                    connection.setReadTimeout(100000);
                    connection.setDoOutput(true);
                    connection.setDoInput(true);
                    connection.setRequestProperty("Content-Type",
                            "application/json;charset=UTF-8");
                    Log.d("HttpUtil", jb.toString());
                    //将数据写给服务器
                    DataOutputStream out= new DataOutputStream(connection.getOutputStream());
                    out.writeBytes(jb.toString());
                    //成功
                    if(connection.getResponseCode()==200){
                        Log.e("HttpUtil", "success");
                        InputStream in=connection.getInputStream();
                        BufferedReader reader=new BufferedReader(new InputStreamReader(in,"utf-8"));
                        String line;
                        while ((line=reader.readLine())!=null){
                            sb.append(line);
                        }
                        Log.e(TAG, "返回的数据是    "+sb.toString() );
                        //执行跳转回登录界面的逻辑
                        handler.sendEmptyMessage(1);
                    }else{
                        Log.e("HttpUtil",Integer.toString(connection.getResponseCode()));
                        Log.e("HttpUtil","fail");
                    }

                } catch (MalformedURLException e) {
                    e.printStackTrace();
                    Log.e(TAG, "sendHttpPostRequest: 找不到URL");
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                } finally {
                    if (connection !=null){
                        connection.disconnect();
                    }
                }
            }
        }).start();

    }
    class MyLintener implements View.OnClickListener{

        @Override
        public void onClick(View v) {
            payLoadData = payload.getText().toString();
            String qosDataString=qos.getText().toString();
            boolean isInt=qosDataString.matches("[0-9]+");
            if (isInt){
                qosData=Integer.parseInt(qosDataString);
                topicData = topic.getText().toString();
                if (payload.equals("")||
                        (topicData).equals("")){
                    Toast.makeText(send_publish.this,
                            "您输入的内容不能为空", Toast.LENGTH_SHORT).show();
                }else {
                    publishBo=new publishBo(payLoadData,qosData,topicData);
                    sendHttpPostRequest(publishBo);
                }
            }else {
                Toast.makeText(send_publish.this,"qos需输入整数,请重新输入",Toast.LENGTH_SHORT).show();
            }

        }
    }
}
