package publish;

import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.myapp.R;
import com.example.myapp.showDataActivity;
import com.google.gson.Gson;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import login.MainActivity;
import model.publishResponse;

public class publishByTopic extends AppCompatActivity implements View.OnClickListener {

    private EditText editText;
    private Button button;
    private String editString;
    public publishResponse.DataBean DataBean;
    private int records;
    private List<publishResponse.DataBean.RowsBean> rows;
    private static final String TAG = "publishByTopic";
    public static String MyUrl = "http://iotc.okay3r.top";
    private String jsonData;
    private Handler handler=new Handler(){
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what){
                case 1:
                    if (jsonData!=null){
                        parsejSONData(jsonData);
                        View view=findViewById(R.id.show_view_publish);
                        LinearLayout lin=findViewById(R.id.show_topic_lin);
                        ListView listView=findViewById(R.id.list_view_topic_publish);
                        view.setVisibility(View.VISIBLE);
                        lin.setVisibility(View.VISIBLE);
                        listView.setAdapter(new adapter());
                    }
                    break;
            }
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_publish_by_topic);
        editText = findViewById(R.id.search_publish_topic);
        button = findViewById(R.id.commit_publish_topic);
        editString = editText.getText().toString();
        button.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.commit_publish_topic:
                //使用Volley框架请求数据
                RequestQueue requestQueue= Volley.newRequestQueue(this);
                StringRequest stringRequest=new StringRequest(MyUrl+"/pub/queryByTopic?topic="+editString, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.e(TAG, "onResponse: "+response);
                        jsonData = response;
                        handler.sendEmptyMessage(1);
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(publishByTopic.this,"没找到哦",Toast.LENGTH_SHORT).show();
                        Log.e(TAG, "onErrorResponse: "+"请求失败" );
                    }
                }){
                    //设置请求头
                    @Override
                    public Map<String, String> getHeaders() throws AuthFailureError {
                        HashMap<String ,String> map=new HashMap<>();
                        map.put("username", MainActivity.username);
                        map.put("secretKey", MainActivity.key);
                        return map;
                    }
                };
                requestQueue.add(stringRequest);
                break;
        }
    }
    public void parsejSONData(String jsonData){
        Gson gson=new Gson();
        publishResponse json = gson.fromJson(jsonData, publishResponse.class);
        DataBean= json.getData();
        records = DataBean.getRecords();
        rows = DataBean.getRows();
    }
    class adapter extends BaseAdapter {

        @Override
        public int getCount() {
            return rows.size();
        }

        @Override
        public Object getItem(int position) {
            return rows.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view= LayoutInflater.from(publishByTopic.this).inflate(R.layout.show_publish_list_item,null);
            TextView userName= view.findViewById(R.id.pub_userName);
            TextView topic= view.findViewById(R.id.pub_topic);
            TextView qos= view.findViewById(R.id.pub_qos);
            TextView payLoad= view.findViewById(R.id.pub_payload);
            TextView time= view.findViewById(R.id.pub_time);
            userName.setText(rows.get(position).getUsername());
            topic.setText(rows.get(position).getTopic());
            qos.setText(rows.get(position).getQos()+"");
            payLoad.setText(rows.get(position).getPayload());
            String timeData=rows.get(position).getTime();
            char[] array = timeData.toCharArray();
            StringBuffer buffer=new StringBuffer();
            for (int i = 0; i <array.length ; i++) {
                if (i<= 9 || (i>=11 && i<=18)){
                    buffer.append(array[i]);
                }
                if (i==10){
                    buffer.append(" ");
                }
            }
            time.setText(buffer.toString());
            return view;
        }
    }
}
