package publish;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.example.myapp.R;
import com.google.gson.Gson;

import java.util.List;

import model.publishResponse;

public class show_publish_by_time extends AppCompatActivity {

    private ListView listView;
    private TextView tv;
    public publishResponse.DataBean DataBean;
    private int records;
    private List<publishResponse.DataBean.RowsBean> rows;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_publish_by_time);
        tv = findViewById(R.id.publish_records_show);
        listView = findViewById(R.id.time_publish_listView);
        String jsonData=getIntent().getStringExtra("publishTimeData");
        parsejSONData(jsonData);
        tv.setText("共有"+records+"条记录");
        listView.setAdapter(new adapter());
    }
    class adapter extends BaseAdapter {

        @Override
        public int getCount() {
            return rows.size();
        }

        @Override
        public Object getItem(int position) {
            return rows.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view= LayoutInflater.from(show_publish_by_time.this).inflate(R.layout.show_publish_list_item,null);
            TextView userName= view.findViewById(R.id.pub_userName);
            TextView topic= view.findViewById(R.id.pub_topic);
            TextView qos= view.findViewById(R.id.pub_qos);
            TextView payLoad= view.findViewById(R.id.pub_payload);
            TextView time= view.findViewById(R.id.pub_time);
            userName.setText(rows.get(position).getUsername());
            topic.setText(rows.get(position).getTopic());
            qos.setText(rows.get(position).getQos()+"");
            payLoad.setText(rows.get(position).getPayload());
            String timeData=rows.get(position).getTime();
            char[] array = timeData.toCharArray();
            StringBuffer buffer=new StringBuffer();
            for (int i = 0; i <array.length ; i++) {
                if (i<= 9 || (i>=11 && i<=18)){
                    buffer.append(array[i]);
                }
                if (i==10){
                    buffer.append(" ");
                }
            }
            time.setText(buffer.toString());
            return view;
        }
    }
    public void parsejSONData(String jsonData){
        Gson gson=new Gson();
        publishResponse json = gson.fromJson(jsonData, publishResponse.class);
        DataBean= json.getData();
        records = DataBean.getRecords();
        rows = DataBean.getRows();
    }
}
