package login;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.myapp.R;
import com.example.myapp.showDataActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import model.loginUser;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    //登录请求的URL
    private String MyURL="http://iotc.okay3r.top//passport/login";
    private Button login;
    private Button register;
    //下面的订阅需要发这两个字符串
    public static  String username;
    public static  String key;

    private EditText passwordEdit;
    private EditText userNameEdit;
    private loginUser loginUserModel;
    private static final String TAG = "MainActivity";
    private Handler handler=new Handler(){
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what){
                case 1:
                    Toast.makeText(MainActivity.this,"登录成功",
                            Toast.LENGTH_SHORT).show();
                    //跳转界面
                    Intent intent=new Intent(MainActivity.this, showDataActivity.class);
                    startActivity(intent);
                    break;
                case 2:
                    Toast.makeText(MainActivity.this,"用户名密码错误或账号不存在!!!",
                            Toast.LENGTH_SHORT).show();
                    break;
            }
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        userNameEdit = findViewById(R.id.register_userName);
        passwordEdit = findViewById(R.id.register_password);
        //登录按钮
        login = findViewById(R.id.login);
        //注册按钮
        register = findViewById(R.id.register);
       // initPermission();
        login.setOnClickListener(this);
        register.setOnClickListener(this);

    }
    private void initPermission(){
        int permission_write= ContextCompat.checkSelfPermission(MainActivity.this,
                Manifest.permission.INTERNET);
        if(permission_write!= PackageManager.PERMISSION_GRANTED){
            Toast.makeText(this, "正在请求权限", Toast.LENGTH_LONG).show();
            //申请权限，特征码自定义为1，可在回调时进行相关判断
            ActivityCompat.requestPermissions(MainActivity.this,
                    new String[]{Manifest.permission.INTERNET,
                    },1);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode){
            case 1:
                if(grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED){
                    //权限已成功申请
                    Toast.makeText(this, "网络权限成功申请", Toast.LENGTH_SHORT).show();
                }else{
                    //用户拒绝授权
                    Toast.makeText(this, "无法获取网络权限", Toast.LENGTH_SHORT).show();
                    finish();
                }
                break;
            default:
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.login:
                //TODO  登录界面逻辑
                //得到提示框内容
                String userName=userNameEdit.getText().toString();
                String password=passwordEdit.getText().toString();
                loginUserModel=new loginUser(userName,password);
                if (userName.equals("") || password.equals("")){
                    Toast.makeText(MainActivity.this,
                            "用户名和密码不能为空",Toast.LENGTH_SHORT).show();
                }else {

                    sendHttpPostRequest(loginUserModel);
                }
                break;
            case R.id.register:
                //TODO 注册界面逻辑
                Intent intent=new Intent(this, registerActivity.class);
                startActivity(intent);
                break;
        }
    }
    //通过post方式请求数据
    private void sendHttpPostRequest(final loginUser loginUserModel) {
        //开启线程请求服务器返回的数据
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    StringBuilder sb=new StringBuilder();
                    //发送post请求
                    //Post请求query部分要拼接在URL中属性之间用&隔开，第一个属性加?
                    URL url=new URL(MyURL+"?username="+loginUserModel.getUserName()+
                            "&password="+loginUserModel.getPassword());
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("POST");
                    connection.setConnectTimeout(100000);
                    connection.setReadTimeout(100000);
                    connection.setDoOutput(true);
                    connection.setDoInput(true);
                    connection.setRequestProperty("Content-Type",
                            "application/json;charset=UTF-8");
                    Log.e("HttpUtil", sb.toString());
                    //成功接收到服务端数据
                    if(connection.getResponseCode()==200){
                        Log.e("HttpUtil", "success");
                        InputStream in=connection.getInputStream();
                        BufferedReader reader=new BufferedReader(new InputStreamReader(in,"utf-8"));
                        String line;
                        while ((line=reader.readLine())!=null){
                            sb.append(line);
                        }
                        Log.e(TAG, "返回的数据是    "+sb.toString() );
                        //将key存起来
                        JSONObject jsonObject=new JSONObject(sb.toString());
                         key= (String) jsonObject.get("data");
                         //去掉字符串的空格
                         key.trim();
                         Log.e(TAG, ""+key );
                        username=loginUserModel.getUserName();
                        //执行跳转回登录界面的逻辑
                        handler.sendEmptyMessage(1);
                    }else{
                        handler.sendEmptyMessage(2);
                        Log.e("HttpUtil",Integer.toString(connection.getResponseCode()));
                        Log.e("HttpUtil","fail");
                    }
            } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
    }).start();
    }
}
