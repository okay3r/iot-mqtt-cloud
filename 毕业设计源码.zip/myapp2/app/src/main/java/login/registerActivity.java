package login;

import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.myapp.R;
import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import model.UserBo;

public class registerActivity extends AppCompatActivity {
    private static final String TAG = "registerActivity";
    //注册请求的URL
    private String MyURL="http://iotc.okay3r.top/passport/register";
    private EditText input_userName;
    private EditText input_password;
    private EditText input_phone;
    private EditText input_remark;
    private EditText input_email;
    UserBo userBo;
    Gson gson;
    private Button input_register;
    //跳转回主页面
    private Handler handler=new Handler(){
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what){
                case 1:
                    //跳转到登录界面
                    Intent intent=new Intent(registerActivity.this, MainActivity.class);
                    startActivity(intent);
                    Toast.makeText(registerActivity.this,"注册成功",Toast.LENGTH_SHORT).show();
                    break;
            }

        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        input_userName = findViewById(R.id.input_userName);
        input_password = findViewById(R.id.input_password);
        input_phone = findViewById(R.id.input_phone);
        input_remark = findViewById(R.id.input_remark);
        input_email = findViewById(R.id.input_email);
        input_register = findViewById(R.id.input_register);
        input_register.setOnClickListener(new MyListener());
    }
    private void sendHttpPostRequest(final UserBo userBo){
        //开启一个线程进行网络请求
        new Thread(new Runnable() {
            HttpURLConnection connection;
            @Override
            public void run() {
                try {
                    StringBuilder sb=new StringBuilder();
                    //向json对象中添加数据
                    JSONObject jb=new JSONObject();
                 //   jb.put("用户对象BO",userBo);
                    jb.put("username",userBo.getUserName());
                    jb.put("password",userBo.getPassword());
                    jb.put("phone",userBo.getPhone());
                    jb.put("remark",userBo.getRemark());
                    jb.put("email",userBo.getEmail());
                    //发送post请求
                    URL url=new URL(MyURL);
                    connection= (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("POST");
                    connection.setConnectTimeout(10000);
                    connection.setReadTimeout(10000);
                    connection.setDoOutput(true);
                    connection.setUseCaches(false);
                    connection.setInstanceFollowRedirects(true);
                    connection.setDoInput(true);
                    connection.setRequestProperty("Content-Type",
                            "application/json;charset=UTF-8");
                    Log.e("HttpUtil", jb.toString());
                    //将数据写给服务器
                   DataOutputStream out= new DataOutputStream(connection.getOutputStream());
                    connection.connect();
                    out.writeBytes(jb.toString());
                    out.flush();

                    //成功
                    if(connection.getResponseCode()==200){
                        Log.e("HttpUtil", "success");
                        InputStream in=connection.getInputStream();
                        BufferedReader reader=new BufferedReader(new InputStreamReader(in,"utf-8"));
                        String line;
                        while ((line=reader.readLine())!=null){
                            sb.append(line);
                        }
                        Log.e(TAG, "返回的数据是    "+sb.toString() );
                        //执行跳转回登录界面的逻辑
                        handler.sendEmptyMessage(1);
                    }else{
                        Log.e("HttpUtil",Integer.toString(connection.getResponseCode()));
                        Log.e("HttpUtil","fail");
                    }

                } catch (MalformedURLException e) {
                    e.printStackTrace();
                    Log.e(TAG, "sendHttpPostRequest: 找不到URL");
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                } finally {
                    if (connection !=null){
                        connection.disconnect();
                    }
                }
            }
        }).start();

    }

    //给注册按钮设置监听器
    class MyListener implements View.OnClickListener{

        @Override
        public void onClick(View v) {
            String user_name=input_userName.getText().toString();
            String password=input_password.getText().toString();
            String phone=input_phone.getText().toString();
            String remark=input_remark.getText().toString();
            String email=input_email.getText().toString();
            if (user_name.equals("")||
             (password).equals("")||
             (phone).equals("")||
             (remark).equals("")||
             (email).equals("")){
                Toast.makeText(registerActivity.this,
                        "您输入的内容不能为空",Toast.LENGTH_SHORT).show();
            }else {
                userBo=new UserBo(user_name,password,email,remark,phone);
                //发送post请求
                sendHttpPostRequest(userBo);
            }
        }
    }
}
