package com.example.myapp;

import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.android.volley.AuthFailureError;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import login.MainActivity;
import publish.publishByTime;
import publish.publishByTopic;
import publish.send_publish;
import publish.showPublishData;
import subscribe.SubSerachByTopic;
import subscribe.subByDateActivity;
import subscribe.subcribeActivity;

public class showDataActivity extends AppCompatActivity implements View.OnClickListener {

    private static final String TAG = "showDataActivity";
    private Button subscribe;
    private Button subscribe_time;
    private Button subscribe_date;
    private Button sendMessage;
    private Button search_publish;
    private Button search_publish_for_time;
    private Button search_publish_for_topic;
    private Button search_publish_all;
    public String data;
    String MyUrl = "http://iotc.okay3r.top";
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 1:
                    //跳转界面
                    Intent intent = new Intent(showDataActivity.this, subcribeActivity.class);
                    intent.putExtra("subcribeData", data);
                    startActivity(intent);
                    break;
                case 2:
                    Intent intent2=new Intent(showDataActivity.this,search_publish_all_activity.class);
                    intent2.putExtra("publish_all",data);
                    startActivity(intent2);
                    break;

            }
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_data);
        subscribe = findViewById(R.id.subscribe);
        subscribe_time = findViewById(R.id.subscribeByTime);
        subscribe_date = findViewById(R.id.subscribeByDate);
        sendMessage = findViewById(R.id.sendMessage);
        search_publish = findViewById(R.id.search_publish);
        search_publish_for_time = findViewById(R.id.search_publish_for_time);
        search_publish_for_topic = findViewById(R.id.search_publish_for_topic);
        search_publish_all = findViewById(R.id.search_publish_all);

        //设置监听器
        subscribe.setOnClickListener(this);
        subscribe_time.setOnClickListener(this);
        subscribe_date.setOnClickListener(this);
        sendMessage.setOnClickListener(this);
        search_publish.setOnClickListener(this);
        search_publish_for_time.setOnClickListener(this);
        search_publish_for_topic.setOnClickListener(this);
        search_publish_all.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            //TODO  查询订阅记录
            case R.id.subscribe:
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            URL url = new URL(MyUrl + "/sub/list");
                            Log.e(TAG, "" + url.toString());
                            Log.e(TAG, MainActivity.key + "  " + MainActivity.username);
                            StringBuilder response = new StringBuilder();
                            HttpURLConnection connection = getHttpURLConnection(url);
                            //200表示连接成功
                            if (connection.getResponseCode() == 200) {
                                InputStream in = connection.getInputStream();
                                BufferedReader reader = new BufferedReader(new InputStreamReader(in, "UTF-8"));
                                String line;
                                while ((line = reader.readLine()) != null) {
                                    response.append(line);
                                }
                                data = response.toString();
                                reader.close();
                                in.close();
                                connection.disconnect();
                                handler.sendEmptyMessage(1);
                                Log.e(TAG, "得到的数据是   " + response.toString());
                            } else {
                                System.out.println(connection.getResponseCode());
                                Log.e("HttpUtil", "fail");
                            }
                        } catch (MalformedURLException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }).start();
                break;
            case R.id.subscribeByTime:
                //TODO 根据时间查阅
                //跳转界面
                final Intent intent=new Intent(showDataActivity.this, subByDateActivity.class);
                startActivity(intent);
                break;
            case R.id.subscribeByDate:
                //TODO 模糊查询订阅记录
                Intent intent1=new Intent(showDataActivity.this, SubSerachByTopic.class);
                startActivity(intent1);
                break;
            case R.id.sendMessage:
                //TODO 发送消息
            Intent intent2=new Intent(showDataActivity.this, send_publish.class);
            startActivity(intent2);
            break;
            case R.id.search_publish:
                //TODO 查询publish
                //使用Volley框架请求数据
                RequestQueue requestQueue= Volley.newRequestQueue(this);
                StringRequest stringRequest=new StringRequest(MyUrl+"/pub/list", new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.e(TAG, "onResponse: "+response);
                        Intent intent3=new Intent(showDataActivity.this, showPublishData.class);
                        intent3.putExtra("publishData",response);
                        startActivity(intent3);
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e(TAG, "onErrorResponse: "+"请求失败" );
                    }
                }){
                    //设置请求头
                    @Override
                    public Map<String, String> getHeaders() throws AuthFailureError {
                        HashMap<String ,String> map=new HashMap<>();
                        map.put("username",MainActivity.username);
                        map.put("secretKey", MainActivity.key);
                        return map;
                    }
                };

                requestQueue.add(stringRequest);
                break;
            case R.id.search_publish_for_time:
                //TODO 根据时间范围查找publish
                Intent intent3=new Intent(showDataActivity.this, publishByTime.class);
                startActivity(intent3);
                break;
            case R.id.search_publish_for_topic:
                //TODO 根据话题模糊查询
                Intent intent4=new Intent(showDataActivity.this, publishByTopic.class);
                startActivity(intent4);
                break;
            case R.id.search_publish_all:
                //TODO 查询全部订阅信息
                //使用Volley框架请求数据
                RequestQueue requestQueue2= Volley.newRequestQueue(this);
                StringRequest stringRequest2=new StringRequest(MyUrl+"/client/subscriptions", new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.e(TAG, "onResponse: "+response);
                        Intent intent3=new Intent(showDataActivity.this,
                                search_publish_all_activity.class);
                        intent3.putExtra("publishAll",response);
                        startActivity(intent3);
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e(TAG, "onErrorResponse: "+"请求失败" );
                    }
                }){
                    //设置请求头
                    @Override
                    public Map<String, String> getHeaders() throws AuthFailureError {
                        HashMap<String ,String> map=new HashMap<>();
                        map.put("username",MainActivity.username);
                        map.put("secretKey", MainActivity.key);
                        return map;
                    }
                };
                requestQueue2.add(stringRequest2);
                break;

        }
    }

    public static HttpURLConnection getHttpURLConnection(URL url) throws IOException {
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");

        //请求添加密钥和用户名
        connection.setRequestProperty("username", MainActivity.username);
        connection.setRequestProperty("secretKey", MainActivity.key);

        connection.setConnectTimeout(10000);
        connection.setReadTimeout(10000);
        connection.setRequestProperty("Content-Type", "application/json");
        return connection;
    }

}

