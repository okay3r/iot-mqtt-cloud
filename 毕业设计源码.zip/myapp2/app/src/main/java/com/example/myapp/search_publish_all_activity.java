package com.example.myapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import login.MainActivity;
import model.client;


public class search_publish_all_activity extends AppCompatActivity implements  View.OnClickListener{

    private ListView listView;
    private String clientId;
    private Button btn;
    String MyUrl = "http://iotc.okay3r.top";
    private static final String TAG = "search_publish_all_acti";
    private TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_publish_all_activity);
     //   listView = findViewById(R.id.publish_all);
        String data_intent = getIntent().getStringExtra("publishAll");
        Log.e(TAG, "onCreate: "+data_intent );
        parsejSONData(data_intent);
        btn = findViewById(R.id.set_client_info);
        btn.setOnClickListener(this);
        tv = findViewById(R.id.publish_tv_all);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.set_client_info:
                RequestQueue requestQueue2= Volley.newRequestQueue(this);
                StringRequest stringRequest2=new StringRequest(Request.Method.POST,MyUrl+"/client/setClientInfo?clientId="+clientId, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.e(TAG, "onResponse: "+response);
                        try {
                            JSONObject object=new JSONObject(response);
                            String data= object.getString("data");
                            if (data!=null){
                                tv.setText(data);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e(TAG, "onErrorResponse: "+"请求失败" );
                    }
                }){
                    //设置请求头
                    @Override
                    public Map<String, String> getHeaders() throws AuthFailureError {
                        HashMap<String ,String> map=new HashMap<>();
                        map.put("username", MainActivity.username);
                        map.put("secretKey", MainActivity.key);
                        return map;
                    }
                };
                requestQueue2.add(stringRequest2);
                break;
        }
    }
    public void parsejSONData(String jsonData){
        Gson gson=new Gson();
        client json = gson.fromJson(jsonData, client.class);
        List<client.DataBean> data = json.getData();
        clientId= data.get(0).getClientId();
    }
  /*  class myAdapter extends BaseAdapter{

        @Override
        public int getCount() {
            return publish_list.size();
        }

        @Override
        public Object getItem(int position) {
            return publish_list.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view=LayoutInflater.from(parent.getContext()).inflate(R.layout.publish_all_item,null);
            TextView textView= view.findViewById(R.id.pub_list_item);
            if (publish_list.get(position).equals("") || publish_list.get(position)==null){
                textView.setText("没有查询到记录");
            }else {
                textView.setText(publish_list.get(position).toString());
            }
            return view;
        }
    }*/

}
