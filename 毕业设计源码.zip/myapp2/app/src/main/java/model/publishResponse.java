package model;

import java.util.List;

public class publishResponse {


    /**
     * status : 200
     * msg : OK
     * data : {"page":1,"total":1,"records":5,"rows":[{"id":2,"username":"tom","topic":"iotc/p1","payload":"hello aaa","qos":1,"success":1,"time":"2020-04-06T14:21:51.000+0000"},{"id":3,"username":"zlz","topic":"hahha","payload":"hah","qos":1,"success":1,"time":"2020-04-10T05:29:50.000+0000"},{"id":4,"username":"zlz","topic":"212","payload":"1234","qos":0,"success":1,"time":"2020-04-10T05:30:38.000+0000"},{"id":5,"username":"zlz","topic":"ha","payload":"ha","qos":1,"success":1,"time":"2020-04-10T05:31:59.000+0000"},{"id":6,"username":"zlz","topic":"d","payload":"2","qos":1,"success":1,"time":"2020-04-10T05:32:22.000+0000"}]}
     */

    private int status;
    private String msg;
    private DataBean data;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public  class DataBean {
        /**
         * page : 1
         * total : 1
         * records : 5
         * rows : [{"id":2,"username":"tom","topic":"iotc/p1","payload":"hello aaa","qos":1,"success":1,"time":"2020-04-06T14:21:51.000+0000"},{"id":3,"username":"zlz","topic":"hahha","payload":"hah","qos":1,"success":1,"time":"2020-04-10T05:29:50.000+0000"},{"id":4,"username":"zlz","topic":"212","payload":"1234","qos":0,"success":1,"time":"2020-04-10T05:30:38.000+0000"},{"id":5,"username":"zlz","topic":"ha","payload":"ha","qos":1,"success":1,"time":"2020-04-10T05:31:59.000+0000"},{"id":6,"username":"zlz","topic":"d","payload":"2","qos":1,"success":1,"time":"2020-04-10T05:32:22.000+0000"}]
         */

        private int page;
        private int total;
        private int records;
        private List<RowsBean> rows;

        public int getPage() {
            return page;
        }

        public void setPage(int page) {
            this.page = page;
        }

        public int getTotal() {
            return total;
        }

        public void setTotal(int total) {
            this.total = total;
        }

        public int getRecords() {
            return records;
        }

        public void setRecords(int records) {
            this.records = records;
        }

        public List<RowsBean> getRows() {
            return rows;
        }

        public void setRows(List<RowsBean> rows) {
            this.rows = rows;
        }

        public  class RowsBean {
            /**
             * id : 2
             * username : tom
             * topic : iotc/p1
             * payload : hello aaa
             * qos : 1
             * success : 1
             * time : 2020-04-06T14:21:51.000+0000
             */

            private int id;
            private String username;
            private String topic;
            private String payload;
            private int qos;
            private int success;
            private String time;

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getUsername() {
                return username;
            }

            public void setUsername(String username) {
                this.username = username;
            }

            public String getTopic() {
                return topic;
            }

            public void setTopic(String topic) {
                this.topic = topic;
            }

            public String getPayload() {
                return payload;
            }

            public void setPayload(String payload) {
                this.payload = payload;
            }

            public int getQos() {
                return qos;
            }

            public void setQos(int qos) {
                this.qos = qos;
            }

            public int getSuccess() {
                return success;
            }

            public void setSuccess(int success) {
                this.success = success;
            }

            public String getTime() {
                return time;
            }

            public void setTime(String time) {
                this.time = time;
            }
        }
    }
}
