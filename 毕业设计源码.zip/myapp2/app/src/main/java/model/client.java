package model;

import java.util.List;

public class client {

    /**
     * status : 200
     * msg : OK
     * data : [{"id":null,"clientId":"wendu1586693446394","node":"emqx@127.0.0.1","topic":"iotc/#","qos":2,"clientName":null,"remark":null,"updateTime":null}]
     */

    private int status;
    private String msg;
    private List<DataBean> data;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public List<DataBean> getData() {
        return data;
    }

    public void setData(List<DataBean> data) {
        this.data = data;
    }

    public class DataBean {
        /**
         * id : null
         * clientId : wendu1586693446394
         * node : emqx@127.0.0.1
         * topic : iotc/#
         * qos : 2
         * clientName : null
         * remark : null
         * updateTime : null
         */

        private Object id;
        private String clientId;
        private String node;
        private String topic;
        private int qos;
        private Object clientName;
        private Object remark;
        private Object updateTime;

        public Object getId() {
            return id;
        }

        public void setId(Object id) {
            this.id = id;
        }

        public String getClientId() {
            return clientId;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public String getNode() {
            return node;
        }

        public void setNode(String node) {
            this.node = node;
        }

        public String getTopic() {
            return topic;
        }

        public void setTopic(String topic) {
            this.topic = topic;
        }

        public int getQos() {
            return qos;
        }

        public void setQos(int qos) {
            this.qos = qos;
        }

        public Object getClientName() {
            return clientName;
        }

        public void setClientName(Object clientName) {
            this.clientName = clientName;
        }

        public Object getRemark() {
            return remark;
        }

        public void setRemark(Object remark) {
            this.remark = remark;
        }

        public Object getUpdateTime() {
            return updateTime;
        }

        public void setUpdateTime(Object updateTime) {
            this.updateTime = updateTime;
        }
    }
}
