package model;

import java.util.List;

public  class sub {
    public int status;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String msg;

    public sub.data getData() {
        return data;
    }

    public void setData(sub.data data) {
        this.data = data;
    }

    public data data;
    public  class data{
        public int page;
        public int total;

        public int getPage() {
            return page;
        }

        public void setPage(int page) {
            this.page = page;
        }

        public int getTotal() {
            return total;
        }

        public void setTotal(int total) {
            this.total = total;
        }

        public int getRecords() {
            return records;
        }

        public void setRecords(int records) {
            this.records = records;
        }

        public List<sub.rows> getRows() {
            return rows;
        }

        public void setRows(List<sub.rows> rows) {
            this.rows = rows;
        }

        public int records;
        public List<rows> rows;
    }
    public static class rows{
        public int id;
        public String topic;
        public int qos;
        public String payload;
        public String time;

        public rows(int id, String topic, int qos, String payload, String time) {
            this.id = id;
            this.topic = topic;
            this.qos = qos;
            this.payload = payload;
            this.time = time;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getTopic() {
            return topic;
        }

        public void setTopic(String topic) {
            this.topic = topic;
        }

        public int getQos() {
            return qos;
        }

        public void setQos(int qos) {
            this.qos = qos;
        }

        public String getPayload() {
            return payload;
        }

        public void setPayload(String payload) {
            this.payload = payload;
        }

        public String getTime() {
            return time;
        }

        public void setTime(String time) {
            this.time = time;
        }
    }

}
