package model;

public class publishBo {
    public String payload;
    public int qos;
    public String topic;

    public publishBo(String payload, int qos, String topic) {
        this.payload = payload;
        this.qos = qos;
        this.topic = topic;
    }

    public String getPayload() {
        return payload;
    }

    public void setPayload(String payload) {
        this.payload = payload;
    }

    public int getQos() {
        return qos;
    }

    public void setQos(int qos) {
        this.qos = qos;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }
}
