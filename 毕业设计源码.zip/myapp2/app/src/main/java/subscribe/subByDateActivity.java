package subscribe;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.TimePicker;

import login.MainActivity;
import com.example.myapp.R;
import com.example.myapp.showDataActivity;
import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import model.sub;

public class subByDateActivity extends AppCompatActivity implements View.OnClickListener {
    private StringBuffer time=new StringBuffer();
    private StringBuffer time2=new StringBuffer();
    String MyUrl = "http://iotc.okay3r.top";
    private String startTime;
    private String endTime;
    private Button startBtn;
    private Button endBtn;
    private Button searchBtn;
    private ListView listView;
    private static final String TAG = "subByDateActivity";
    //返回的json数据
    private String data;
    private List<sub.rows> subList;
    private int total;
    private TextView ev_total;
    private sub.data data1;
    private Handler handler=new Handler(){
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what){
                case 1:
                    Intent intent=new Intent(subByDateActivity.this, show_data_by_time.class);
                    intent.putExtra("subByDate",data);
                    startActivity(intent);
                    break;
            }
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub_by_date);
        subList=new ArrayList<>();
        parseJSONData(data);
        startBtn = findViewById(R.id.start_time_btn);
        endBtn = findViewById(R.id.end_time_btn);
        searchBtn = findViewById(R.id.time_sub_search);
        ev_total = findViewById(R.id.search_total_res);
        startBtn.setOnClickListener(this);
        endBtn.setOnClickListener(this);
        searchBtn.setOnClickListener(this);
    }
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.start_time_btn:
                showDate();
                showTime();
                break;
            case R.id.end_time_btn:
                showEndDate();
                showEndTime();
                break;
            case R.id.time_sub_search:
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Log.e(TAG, time.toString() );
                            String aa=URLEncoder.encode(startTime,"utf-8");
                            String bb=URLEncoder.encode(endTime,"utf-8");
                            URL url = new URL(MyUrl + "/sub/queryByTime?start="+aa+"&end="+bb);
                            Log.e(TAG, "" + url.toString());
                            Log.e(TAG, MainActivity.key + "  " + MainActivity.username);
                            StringBuilder response = new StringBuilder();
                            HttpURLConnection connection = showDataActivity.getHttpURLConnection(url);
                            //200表示连接成功
                            if (connection.getResponseCode() == 200) {
                                InputStream in = connection.getInputStream();
                                BufferedReader reader = new BufferedReader(new InputStreamReader(in, "UTF-8"));
                                String line;
                                while ((line = reader.readLine()) != null) {
                                    response.append(line);
                                }
                                data = response.toString();
                                handler.sendEmptyMessage(1);
                                Log.e(TAG, "得到的数据是   " + response.toString());
                            } else {
                                System.out.println(connection.getResponseCode());
                                Log.e("HttpUtil", "fail");
                            }
                        } catch (MalformedURLException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }).start();
                break;
                default:
                    break;
        }
    }
      //选择开始时间
   public void showTime(){
       Calendar cal=Calendar.getInstance();
       int year=cal.get(Calendar.YEAR);
       final int month=cal.get(Calendar.MONTH);
       final int day=cal.get(Calendar.DAY_OF_MONTH);
       new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
           @Override
           public void onDateSet(DatePicker datePicker, int selectYear, int selectMonth, int selectDay) {
               time.append(selectYear).append("/").append(selectMonth+1).append("/").append(selectDay).append(" ");
           }
       },year,month,day).show();
    }
    //选择结束时间
    public void showDate(){
        Calendar cal2=Calendar.getInstance();
         int hour=cal2.get(Calendar.HOUR);
         int min=cal2.get(Calendar.MINUTE);
         final int sec=cal2.get(Calendar.SECOND);
         new TimePickerDialog(this,new TimePickerDialog.OnTimeSetListener() {
             @Override
             public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                 time.append(hourOfDay).append(":").append(minute).append(":").append(sec);
                 startTime = time.toString();
                 Log.e(TAG, startTime+" " );
             }
         },hour,min,true).show();
    }
    //选择结束时间
    public void showEndTime(){
        Calendar cal=Calendar.getInstance();
        int year=cal.get(Calendar.YEAR);
        final int month=cal.get(Calendar.MONTH);
        final int day=cal.get(Calendar.DAY_OF_MONTH);
        new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int selectYear, int selectMonth, int selectDay) {
                time2.append(selectYear).append("/").append(selectMonth+1).append("/").append(selectDay).append(" ");
            }
        },year,month,day).show();
    }
    //选择结束时间
    public void showEndDate(){
        Calendar cal2=Calendar.getInstance();
        int hour=cal2.get(Calendar.HOUR);
        int min=cal2.get(Calendar.MINUTE);
        final int sec=cal2.get(Calendar.SECOND);
        new TimePickerDialog(this,new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                 time2.append(hourOfDay).append(":").append(minute).append(":").append(sec);
                endTime = time2.toString();
                Log.e(TAG, endTime+" " );
            }
        },hour,min,true).show();
    }
    private void parseJSONData(String jsonData) {
        Gson gson = new Gson();
        sub sub1 = gson.fromJson(jsonData, sub.class);
        if (sub1!=null) {
            data1 = sub1.getData();
            subList = data1.getRows();
            total = data1.getRecords();
        }
    }
}
