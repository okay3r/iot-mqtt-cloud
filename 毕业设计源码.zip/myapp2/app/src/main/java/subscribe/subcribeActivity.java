package subscribe;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.example.myapp.R;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.List;

import model.sub;

public class subcribeActivity extends AppCompatActivity {

    private ListView listView;
    private TextView total_data;
    private static final String TAG = "subcribeActivity";
    private List<sub.rows> subList;
    private int total;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subcribe);
        String jsonData = getIntent().getStringExtra("subcribeData");
        Log.e(TAG, "onCreate: " + jsonData);
        //解析json数据
        parseJSONData(jsonData);
        listView = findViewById(R.id.sub_search);
        total_data=findViewById(R.id.total_data);
        listView.setAdapter(new adapter());
        total_data.setText("共有"+total+"条订阅信息");
    }

    class adapter extends BaseAdapter {

        @Override
        public int getCount() {
            return subList.size();
        }

        @Override
        public Object getItem(int position) {
            return subList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_sub, null);
            TextView tv_topic = view.findViewById(R.id.sub_topic);
            TextView tv_qos = view.findViewById(R.id.sub_qos);
            TextView tv_playload = view.findViewById(R.id.playload);
            TextView tv_time = view.findViewById(R.id.sub_time);
            tv_topic.setText(subList.get(position).topic);
            tv_qos.setText(subList.get(position).qos+"");
            tv_playload.setText(subList.get(position).payload);
            String time=subList.get(position).time;
            char[] array = time.toCharArray();
            StringBuffer buffer=new StringBuffer();
            for (int i = 0; i <array.length ; i++) {
                if (i<= 9 || (i>=11 && i<=18)){
                    buffer.append(array[i]);
                }
                if (i==10){
                    buffer.append(" ");
                }
            }
            tv_time.setText(buffer.toString());
            return view;
        }
    }

    private void parseJSONData(String jsonData) {
        Gson gson = new Gson();
        sub sub1 = gson.fromJson(jsonData, sub.class);
        sub.data data = sub1.getData();
        subList = data.getRows();
        total=data.getRecords();
    }
}

