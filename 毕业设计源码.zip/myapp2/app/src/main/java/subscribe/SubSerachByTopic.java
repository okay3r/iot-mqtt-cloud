package subscribe;

import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.example.myapp.R;
import com.example.myapp.showDataActivity;
import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import model.sub;
import okhttp3.OkHttpClient;

public class SubSerachByTopic extends AppCompatActivity {

    private EditText ed_commit_topic;
    private Button btn_commit;
     public static String MyUrl = "http://iotc.okay3r.top";
    public String data;
    public String dataReturn;
    private List<sub.rows> subList;
    private LinearLayout lin;
    private View view;
    private ListView listView;
    private Handler handler=new Handler(){
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what){
                case 1:
                    view = findViewById(R.id.show_view);
                    view.setVisibility(View.VISIBLE);
                    lin = findViewById(R.id.show_lin);
                    lin.setVisibility(View.VISIBLE);
                    listView = findViewById(R.id.list_view_topic);
                    adapter adapter=new adapter();
                    listView.setAdapter(adapter);
                    adapter.notifyDataSetChanged();
                    break;
            }
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub_serach_by_topic);
        ed_commit_topic = findViewById(R.id.search_edit_topic);
        btn_commit = findViewById(R.id.commit_topic);
        data = ed_commit_topic.getText().toString();
        btn_commit.setOnClickListener(new MyListener());
    }
    private void parseJSONData(String jsonData) {
        Gson gson = new Gson();
        sub sub1 = gson.fromJson(jsonData, sub.class);
        if (sub1!=null) {
            sub.data data = sub1.getData();
            subList = data.getRows();
        }
    }
    class MyListener implements View.OnClickListener{

        @Override
        public void onClick(View v) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        URL url=new URL(MyUrl+"/sub/queryByTopic?topic="+data);
                        StringBuilder response=new StringBuilder();
                        HttpURLConnection connection = showDataActivity.getHttpURLConnection(url);
                        //200表示连接成功
                        if (connection.getResponseCode() == 200) {
                            InputStream in = connection.getInputStream();
                            BufferedReader reader = new BufferedReader(new InputStreamReader(in, "UTF-8"));
                            String line;
                            while ((line = reader.readLine()) != null) {
                                response.append(line);
                            }
                            dataReturn = response.toString();
                            parseJSONData(dataReturn);
                            Log.e("TAG", "得到的数据是   " + response.toString());
                            handler.sendEmptyMessage(1);
                        } else {
                            Log.e("TAG", "失败了:响应码是 "+connection.getResponseCode() );
                            Log.e("HttpUtil", "fail");
                        }
                    } catch (MalformedURLException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }).start();
        }
    }
    class adapter extends BaseAdapter {

        @Override
        public int getCount() {
            return subList.size();
        }

        @Override
        public Object getItem(int position) {
            return subList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_sub, null);
            TextView tv_topic = view.findViewById(R.id.sub_topic);
            TextView tv_qos = view.findViewById(R.id.sub_qos);
            TextView tv_playload = view.findViewById(R.id.playload);
            TextView tv_time = view.findViewById(R.id.sub_time);
            tv_topic.setText(subList.get(position).topic);
            tv_qos.setText(subList.get(position).qos+"");
            tv_playload.setText(subList.get(position).payload);
            String time=subList.get(position).time;
            char[] array = time.toCharArray();
            StringBuffer buffer=new StringBuffer();
            for (int i = 0; i <array.length ; i++) {
                if (i<= 9 || (i>=11 && i<=18)){
                    buffer.append(array[i]);
                }
                if (i==10){
                    buffer.append(" ");
                }
            }
            tv_time.setText(buffer.toString());
            return view;
        }
    }

}
